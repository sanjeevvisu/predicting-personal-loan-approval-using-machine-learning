# Predicting_Presonal_Loan_Approval_Using_Machine_Learning

Video Demonstration - https://drive.google.com/file/d/1-Dt4_5sFxkrF6WMVRrNUtCEAoW_S8c2W/view?usp=share_link
